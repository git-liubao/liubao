
%1. Load the image, for example
    image        = imread('img.bmp');
    
%2. Call this function to calculate the quality score:
    qualityscore = SSEQ(image)